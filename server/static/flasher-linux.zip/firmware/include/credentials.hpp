#pragma once

#define WIFI_SSID "sad"
#define WIFI_USERNAME "sad"
#define WIFI_PASSWORD "sad"
#define SERVER_IP IPAddress(1, 2, 3, 4)
