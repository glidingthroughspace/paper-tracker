#pragma once

#define WIFI_SSID "$$WIFI_SSID$$"
#define WIFI_USERNAME "$$WIFI_USERNAME$$"
#define WIFI_PASSWORD "$$WIFI_PASSWORD$$"
#define SERVER_IP IPAddress(0xF0, 0xF1, 0xF2, 0xF3)
